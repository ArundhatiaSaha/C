///All Loops(advance)///
/*
The useage of loop should be remembered.
*/
#include<stdio.h>
int main()
{
    int a=5;




        while(a!=0)
        {
            scanf("%d",&a);

            printf("%d\n\n",a);//Here after printing 0 nothing will be inputed.

        }


       return 0;
}

