///All Loops(advance)///
/*
The useage of loop should be remembered.
*/
#include<stdio.h>
int main()
{
    int a=5;
    int i;
    i=1;

    for(;i<=5;)
    {
        scanf("%d",&a);
        printf("%d\n\n",a);
        i++;
    }


       return 0;
}
