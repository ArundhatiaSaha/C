///While loop///
#include<stdio.h>
int main()
{
    int i,j;
    i=1;
    j=1;
    while(i<=5)
    {
        printf("%d \n",i);
        i++;
    }
    while(j<=5)
    {
        j++;
        printf("%d ",j);
    }
    return 0;
}
