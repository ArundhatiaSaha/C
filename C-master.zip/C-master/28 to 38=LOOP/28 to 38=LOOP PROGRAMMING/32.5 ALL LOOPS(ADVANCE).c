///All Loops(advance)///
/*
The useage of loop should be remembered.
*/
#include<stdio.h>
int main()
{
    int a=5;

        while(scanf("%d",&a) && a!=0)
        {

             printf("%d\n\n",a);//Here after inputing 0 nothing will be printed.

        }


       return 0;
}


