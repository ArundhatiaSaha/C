///Do while///
#include<stdio.h>
int main()
{
    int i;
    i=1;
    do
    {
        printf("%d ",i);//Here a space after %d creates gap between 5 numbers.
        i++;
    }
    while(i<=5);//<-//Here this semi-colon must be remembered.
    return 0;
}
