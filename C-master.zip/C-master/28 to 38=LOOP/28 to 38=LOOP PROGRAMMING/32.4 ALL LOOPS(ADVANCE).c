///All Loops(advance)///
/*
The useage of loop should be remembered.
*/
#include<stdio.h>
int main()
{
    int a=5;


        scanf("%d",&a);

        while(a!=0)
        {

             printf("%d\n\n",a);//Here after inputing 0 nothing will be printed.

             scanf("%d",&a);

        }


       return 0;
}

