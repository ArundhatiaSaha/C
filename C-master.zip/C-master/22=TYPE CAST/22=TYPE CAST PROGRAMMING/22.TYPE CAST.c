#include<stdio.h>
int main()
{
    int a=3,b=2;
    printf("%f",(float)a/(float)b);// Here float type variable is assigned in integer type
    return 0;
}
