#include<stdio.h>
int main()
{
    int var=5,VAR,_to=3,var1=38,var2=103;
    var=34;
    VAR=-28;
    var=var+VAR+_to+var1+var2;
    printf("var=%d",var);
    return 0;
}
/*
VARIABLE=Here value is kept. There are 3 ways to declare variable.
1.Using (underscore: _ )at first;
2.Using (CAPITAL letters(A-Z):A,B,MAN etc.)at first;
3.Using (SMALL letters(a-z):a,b,n,to etc.)at first.

LIMITATION:Keywords can not be declared as variable. Because keywords are reserved for specific works.

KEYWORDS:
32 keywords are written below:-
------------------------------------------------------------------------
! auto ! register  ! int  ! struct ! break   ! else ! short  ! switch  !                                                                  !
!-----------------------------------------------------------------------
! case ! Unsigned  ! enum ! double ! typedef ! char ! extern ! return  !                                                                    !
!-----------------------------------------------------------------------
! for  ! continue  ! void ! signed ! union   ! if   ! while  ! static  !                                                                  !
!-----------------------------------------------------------------------
! goto ! volatile  ! do   ! sizeof ! const   ! long ! float  ! default !                                                      !
!-----------------------------------------------------------------------
*/
