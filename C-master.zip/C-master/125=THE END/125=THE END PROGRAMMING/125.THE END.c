/**
Md. Sharif Chowdhury
Hometown: Dinajpur

B.Sc in CSE
HSTU, Dinajpur

MOBILE: 01737573157
Email: sharif.cse.hstu@gmail.com
Website: techsharif.com

REFERENCE BOOKS:
1)ANCI C -> E. BALAGURUSAMY
2)TECH YOURSELF C -> HERBERT SCHILDT
3)sobar jonno c ->Md. kamruzzaman niton(Bangla Books)
4)THE COMPLETE REFERENCE C-> HERBERT SCHILDT
**/
#include<stdio.h>
int main()
{
    printf("Krishna+Radha && Pranab+Parna\n");
    getchar();///For using this the .exe will not be vanished quickly. It will be stayed for sometimes.
    return 0;
}
