//MATH
#include<stdio.h>
int main()
{
    int a=5,b=7,c,d,ans;
    c=a+b;
    ans=c*c;//(a+b)^2;
    d=a*a-2*a*b+b*b;//(a-b)^2
    printf("%d\n",ans);
    printf("%d\n",d);
    return 0;
}
