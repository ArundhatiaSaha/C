#include<stdio.h>
#include<string.h>
void myf()
{
    printf("This is my function");
}
