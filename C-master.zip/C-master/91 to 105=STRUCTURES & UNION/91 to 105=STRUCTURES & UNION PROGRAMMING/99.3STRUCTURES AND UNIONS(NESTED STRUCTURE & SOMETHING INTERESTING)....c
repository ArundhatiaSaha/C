#include<conio.h>///conio.h=constant input output.header
#include<stdio.h>

int main()
{
    char ch;
    ch = getchar();///Here for any kind of input * will be printed.
    putchar('*');

    return 0;
}
