#include <stdio.h>
int main()
{
    printf("MY FIRST PROGRAM");
    return 0;
}
/*
Two kinds of software are needed for c programming.
1) code editor=This helps to edit code.
2)compiler=This helps to find errors and to run program.compiler works like as interpreter.
{It converts Human language to machine language(0 & 1).}

CODE EDITOR+COMPILER=ID:
EXAMPLE:code block,turbo c etc.

stdio.h=standard input output.header file

#include<stdio.h> = Various kinds of function's defination and source are given here.

main = This is a function which indicates the starting point of a compiler(From where compiler will work).

return 0=It means that the program will return 0; If we use void main instead of int main, return 0 is not needed.

After every full statement we need a semi-colon(;).

printf=This function prints anything you write(Its defination is given on stdio.h).

scanf=This function inputs something(Its defination is given on stdio.h).
*/
