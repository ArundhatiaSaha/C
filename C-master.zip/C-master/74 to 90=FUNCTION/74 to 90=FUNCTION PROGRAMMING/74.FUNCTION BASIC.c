///FUNCTION BASIC

/**
    return_type        => Liquid matter.
    function_name      => Blander(working).
    argument_list      => Mango.
    return_value       => Juce of Mango.
///Function means which works.
///In any C program at least one function must be present.
**/

#include<stdio.h>

int function1 (int a)
{
    return a;
}
int main()


{
    int b;
    b = function1(4);
    printf("%d",b);

    return 0;
}
