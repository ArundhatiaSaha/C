#include<stdio.h>
int main()
{

    int array2d[5][5];

    array2d[1][1]=73;
    array2d[1][2]=75;
    array2d[1][3]=79;
    array2d[1][4]=65;

    printf("%d",array2d[1][3]);

    return 0;

}
