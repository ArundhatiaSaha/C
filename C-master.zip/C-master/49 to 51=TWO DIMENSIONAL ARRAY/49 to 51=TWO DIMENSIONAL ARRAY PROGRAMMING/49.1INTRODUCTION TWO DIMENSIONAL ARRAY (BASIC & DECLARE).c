#include<stdio.h>
int main()
{
    float cgpa[5];
    int mark1[5],mark2[5];

    int array2d[5][5];


    cgpa[1]=3.5;
    cgpa[2]=3.7;
    cgpa[3]=3.8;
    cgpa[4]=3.9;

    mark1[1]=75;
    mark1[2]=85;
    mark1[3]=60;
    mark1[4]=80;

    mark2[1]=75;
    mark2[2]=85;
    mark2[3]=65;
    mark2[4]=80;

    printf("%f\n",cgpa[3]);

    return 0;

}
