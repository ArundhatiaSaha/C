//If-else basic
#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);

    if(a=0)
    {
        printf("%d\n",a);//As '0' means that the statement is false so after a=0 else statement will be printed. But here else statement is not present so nothing will be printed.
    }


    return 0;
}

