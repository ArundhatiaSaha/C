//If-else basic
#include<stdio.h>
int main()
{
    int a;
    scanf("%d",&a);

    if(a>=5)
    {
        printf("%d\n",a);//If we input smaller than 5 then no output will find.
    }


    return 0;
}



