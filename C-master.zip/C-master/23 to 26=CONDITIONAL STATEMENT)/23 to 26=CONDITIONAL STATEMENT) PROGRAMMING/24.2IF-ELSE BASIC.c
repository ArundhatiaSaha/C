//If-else basic
#include<stdio.h>
int main()
{
    int b;

    if(b=5)
    {
        printf("%d\n",b);//Here b=5 means 5 is assigned to b.
    }
/*
    Here in all case 5 will be printed.
    Because all the time the condition is truth.
    And it will print the value of b.
*/
    return 0;
}



