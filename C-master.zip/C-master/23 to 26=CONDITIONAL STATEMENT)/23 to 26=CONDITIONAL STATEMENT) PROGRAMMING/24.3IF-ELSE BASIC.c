//If-else basic
#include<stdio.h>
int main()
{
    int c;
    scanf("%d",&c);
    if(c==4)
    {
        printf("%d\n",c);//Here c==5 means 5 is equal to c.
    }

    return 0;
}




