#include<stdio.h>
int main()
{
    int var;
    char name[7]="PRANAB";
    var=5;
    printf("%d",var+2);
    printf("\n%s",name);
    return 0;
}

/*
KEYWORD=int,return,char etc.
IDENTIFIERS=main,var,printf,name etc.
CONSTANT=5,2 etc.
SPECIAL SYMBOLS=() called Parentheses,{} called Braces or curly brackets,[] called Chevrons or angle brackets.
OPERATORS=+,= etc.
STRING=String is created by connecting many charecters. A NULL charecter is used to indicate the ending point of a STRING.
*/
