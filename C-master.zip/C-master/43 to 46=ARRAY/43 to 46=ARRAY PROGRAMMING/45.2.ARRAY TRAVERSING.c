#include<stdio.h>
int main()
{
    int a[10]={1,4,5,7,45,2,56,107,5,13},i,j;

        printf("%d\n",a[5]);

    return 0;
}
