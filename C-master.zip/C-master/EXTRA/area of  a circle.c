#include <stdio.h>
int main()
{
    float r;

    scanf("%f",&r);

    printf("The area is:%.2f\n",3.14*r*r);
    return 0;
}
