#include<iostream>
using namespace std;
int main()
{
    int i;
    cout<<"Please enter an integer value: "<<endl;
    cin>>i;
    cout<<i<<endl;
    cout<<"Hello World!"<<endl;
    return 0;
}
