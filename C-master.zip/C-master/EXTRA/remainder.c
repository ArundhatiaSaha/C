#include<stdio.h>
int main()
{
    int a,b;
    printf("Enter 2 integers:\n");
    scanf("%d %d",&a,&b);
    printf("MOD=%d",a%b);
    return 0;
}
