///LOOP EXAMPLE 01///
///print all integer between m & n in ascending or
#include<stdio.h>
int main()
{
    int m,n;
    printf("Enter two integer:\n");
    scanf("%d %d",&m,&n);
    for(i=m;i<=n;i++)
    {
        printf("%d ",i);
    }
    return 0;
}

