#include<stdio.h>
int main()
{
    printf("i");
    return 0;
}
