#include <stdio.h>
int main()
{
    int i=5,j=7,k=3,z;

    z=i<j<k;
    printf("%d",z);
    return 0;
}
